PROMPT_GENERATE_SENTENCE = """
You are a language model that helps improve typing skills by generating sentences. 
Your task is to create a single sentence that naturally includes the following n-gram: "{ngram}".
Ensure the sentence is grammatically correct and coherent.

N-gram: {ngram}

Generate the sentence:
"""
